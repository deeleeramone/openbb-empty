# Empty OBBject Extension

This is an empty OpenBB Platform OBBJECT (Response Object) Extension.
