# Empty Provider Extension

This is an empty OpenBB Platform Provider Extension.
