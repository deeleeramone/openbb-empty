"""Empty Provider Models."""
