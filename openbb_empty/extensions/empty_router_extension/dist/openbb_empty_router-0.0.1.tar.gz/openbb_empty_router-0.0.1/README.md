# Empty Router Extension

This is an empty OpenBB Platform Router Extension.
