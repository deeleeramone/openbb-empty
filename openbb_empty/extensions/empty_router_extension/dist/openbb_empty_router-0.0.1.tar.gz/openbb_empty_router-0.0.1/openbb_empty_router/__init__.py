"""An Empty OpenBB Router extension."""
